#!/usr/bin/env python3
import re

with open('app.py', 'r') as f:
    content = f.read()

print("Applying fixes...")

# FIX 1: Add DISTINCT to backup query to prevent doubles from JOIN
old_query = """    backups = db.execute('''
        SELECT 
            bh.*,
            s.name as script_name,
            c.username
        FROM backup_history bh
        LEFT JOIN scripts s ON bh.script_id = s.id
        LEFT JOIN credentials c ON bh.credential_id = c.id
        WHERE bh.device_id = ?
        ORDER BY bh.created_at DESC
        LIMIT 100
    ''', (device_id,)).fetchall()"""

new_query = """    backups = db.execute('''
        SELECT DISTINCT
            bh.*,
            s.name as script_name,
            c.username
        FROM backup_history bh
        LEFT JOIN scripts s ON bh.script_id = s.id
        LEFT JOIN credentials c ON bh.credential_id = c.id
        WHERE bh.device_id = ?
        ORDER BY bh.created_at DESC
        LIMIT 100
    ''', (device_id,)).fetchall()"""

content = content.replace(old_query, new_query)
print("✅ Added DISTINCT to backup query")

# FIX 2: Suppress warnings via environment
old_subprocess = """        # Execute script
        result = subprocess.run(
            ['python3', script_file, ip_address],
            capture_output=True,
            text=True,
            timeout=120
        )"""

new_subprocess = """        # Execute script with suppressed warnings
        import os as os_module
        script_env = os_module.environ.copy()
        script_env['PYTHONWARNINGS'] = 'ignore'
        
        result = subprocess.run(
            ['python3', script_file, ip_address],
            capture_output=True,
            text=True,
            timeout=120,
            env=script_env
        )"""

content = content.replace(old_subprocess, new_subprocess)
print("✅ Added warning suppression")

# FIX 3: Make manual cron run in background
old_manual = """        print(f"[API] Executing job '{job['name']}' manually...")
        
        # Actually run the job!
        run_cron_job(job_id)
        
        print(f"[API] Manual execution of job {job_id} completed")
        return jsonify({'success': True, 'message': 'Job executed successfully'})"""

new_manual = """        print(f"[API] Executing job '{job['name']}' manually...")
        
        # Run in background thread
        import threading
        thread = threading.Thread(target=run_cron_job, args=(job_id,), daemon=True)
        thread.start()
        
        print(f"[API] Manual execution of job {job_id} started in background")
        return jsonify({'success': True, 'message': 'Job started in background'})"""

content = content.replace(old_manual, new_manual)
print("✅ Made cron background")

with open('app.py', 'w') as f:
    f.write(content)

print("✅ All fixes applied!")
