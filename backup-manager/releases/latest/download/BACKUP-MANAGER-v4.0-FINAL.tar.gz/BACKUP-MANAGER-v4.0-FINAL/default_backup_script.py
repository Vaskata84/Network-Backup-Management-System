#!/usr/bin/env python3
"""
UNIVERSAL BACKUP SCRIPT - SSH + Telnet Support
Auto-detects vendor from database
Supports: MikroTik, Cisco, Huawei, Juniper, HPE, Dell, Ubiquiti, D-Link, TP-Link, Planet, Ruby, Arista, and more!
Method: SSH (primary), Telnet (fallback)
Vasil Dobchev - supportpc.org
"""

import telnetlib
import sqlite3
import os
import sys
import time
import json
from datetime import datetime

# Try to import paramiko for SSH
try:
    import paramiko
    SSH_AVAILABLE = True
except ImportError:
    SSH_AVAILABLE = False

DB_PATH = '/data/backup_manager.db'
BACKUP_DIR = '/data/SWITCH_BACKUP'

VENDOR_COMMANDS = {
    'MIKROTIK': {
        'login_prompt': b'Login: ',
        'password_prompt': b'Password: ',
        'enable_prompt': None,
        'prompt': b'> ',
        'commands': ['/export compact'],
        'pagination': False,
        'exit_cmd': '/quit',
        'validation': ['/interface', '/ip', '/system']
    },
    'CISCO': {
        'login_prompt': b'Username: ',
        'password_prompt': b'Password: ',
        'enable_prompt': b'Password: ',
        'prompt': b'#',
        'commands': ['terminal length 0', 'show running-config'],
        'pagination': True,
        'page_prompt': b'--More--',
        'exit_cmd': 'exit',
        'validation': ['interface', 'router', 'version']
    },
    'HUAWEI': {
        'login_prompt': b'Username:',
        'password_prompt': b'Password:',
        'enable_prompt': None,
        'prompt': b'>',
        'commands': ['screen-length 0 temporary', 'display current-configuration'],
        'pagination': True,
        'page_prompt': b'---- More ----',
        'exit_cmd': 'quit',
        'validation': ['interface', 'sysname', 'vlan']
    },
    'JUNIPER': {
        'login_prompt': b'login: ',
        'password_prompt': b'Password:',
        'enable_prompt': None,
        'prompt': b'> ',
        'commands': ['set cli screen-length 0', 'show configuration'],
        'pagination': True,
        'page_prompt': b'----(more',
        'exit_cmd': 'exit',
        'validation': ['interfaces', 'system', 'routing']
    },
    'HPE': {
        'login_prompt': b'Username: ',
        'password_prompt': b'Password: ',
        'enable_prompt': None,
        'prompt': b'#',
        'commands': ['no page', 'show running-config'],
        'pagination': True,
        'page_prompt': b'-- MORE --',
        'exit_cmd': 'exit',
        'validation': ['interface', 'vlan']
    },
    'DELL': {
        'login_prompt': b'User Name:',
        'password_prompt': b'Password:',
        'enable_prompt': None,
        'prompt': b'#',
        'commands': ['terminal length 0', 'show running-config'],
        'pagination': True,
        'page_prompt': b'--More--',
        'exit_cmd': 'exit',
        'validation': ['interface', 'vlan']
    },
    'UBIQUITI': {
        'login_prompt': b'login: ',
        'password_prompt': b'Password:',
        'enable_prompt': None,
        'prompt': b'# ',
        'commands': ['cat /config/config.boot'],
        'pagination': False,
        'exit_cmd': 'exit',
        'validation': ['interface', 'system']
    },
    'D-LINK': {
        'login_prompt': b'UserName:',
        'password_prompt': b'PassWord:',
        'enable_prompt': None,
        'prompt': b'#',
        'commands': ['show config current_config'],
        'pagination': True,
        'page_prompt': b'CTRL+C',
        'exit_cmd': 'logout',
        'validation': ['create', 'config', 'vlan']
    },
    'TP-LINK': {
        'login_prompt': b'User:',
        'password_prompt': b'Password:',
        'enable_prompt': None,
        'prompt': b'#',
        'commands': ['show running-config'],
        'pagination': True,
        'page_prompt': b'--More--',
        'exit_cmd': 'exit',
        'validation': ['interface', 'vlan']
    },
    'PLANET': {
        'login_prompt': b'Username:',
        'password_prompt': b'Password:',
        'enable_prompt': None,
        'prompt': b'#',
        'commands': ['show running-config'],
        'pagination': True,
        'page_prompt': b'--More--',
        'exit_cmd': 'exit',
        'validation': ['interface', 'vlan']
    },
    'RUBY': {
        'login_prompt': b'Username:',
        'password_prompt': b'Password:',
        'enable_prompt': None,
        'prompt': b'#',
        'commands': ['show group', 'show pvid'],
        'pagination': False,
        'exit_cmd': 'exit',
        'validation': ['group', 'pvid', 'port']
    },
    'GENERIC': {
        'login_prompt': b'login: ',
        'password_prompt': b'assword: ',
        'enable_prompt': b'assword: ',
        'prompt': b'#',
        'commands': ['terminal length 0', 'show running-config'],
        'pagination': True,
        'page_prompt': b'--More--',
        'exit_cmd': 'exit',
        'validation': ['interface', 'config']
    }
}

def log(msg):
    print(f"[BACKUP] {msg}", flush=True)

def get_device_info(ip):
    try:
        conn = sqlite3.connect(DB_PATH, timeout=30.0)
        conn.row_factory = sqlite3.Row
        cursor = conn.cursor()
        
        device = cursor.execute('''
            SELECT d.*, v.name as vendor_name
            FROM devices d
            JOIN vendors v ON d.vendor_id = v.id
            WHERE d.ip_address = ?
        ''', (ip,)).fetchone()
        
        if not device:
            log(f"ERROR: Device {ip} not found")
            return None
        
        log(f"Device: {device['hostname']} ({device['vendor_name']})")
        
        # Load credentials from environment OR database
        credentials_json = os.environ.get('CREDENTIALS_JSON', '')
        if credentials_json:
            try:
                credentials = json.loads(credentials_json)
                log(f"Loaded {len(credentials)} credential(s) from environment")
            except:
                credentials = []
        else:
            credentials = []
        
        # Fallback to database
        if not credentials:
            creds = cursor.execute('''
                SELECT id, username, password, enable_password, priority
                FROM credentials
                WHERE vendor_id = ? AND enabled = 1
                ORDER BY priority DESC
            ''', (device['vendor_id'],)).fetchall()
            credentials = [dict(c) for c in creds]
            log(f"Loaded {len(credentials)} credential(s) from database")
        
        conn.close()
        
        if not credentials:
            log(f"ERROR: No credentials for {device['vendor_name']}")
            return None
        
        return {
            'device_id': device['id'],
            'ip': ip,
            'hostname': device['hostname'] if device['hostname'] else ip.replace('.', '_'),
            'port': device['port'] if device['port'] else 23,
            'method': device['method'] if device['method'] else 'telnet',
            'vendor_id': device['vendor_id'],
            'vendor_name': device['vendor_name'],
            'credentials': credentials
        }
    except Exception as e:
        log(f"ERROR: {e}")
        return None

def read_with_pagination(tn, cfg, timeout=120):
    output = b""
    deadline = time.time() + timeout
    stable = 0
    
    while time.time() < deadline:
        try:
            if cfg.get('pagination') and cfg.get('page_prompt'):
                try:
                    chunk = tn.read_until(cfg['page_prompt'], timeout=2)
                    output += chunk
                    if chunk.endswith(cfg['page_prompt']):
                        tn.write(b" ")
                        time.sleep(0.2)
                        stable = 0
                        continue
                except:
                    pass
            
            chunk = tn.read_very_eager()
            if chunk:
                output += chunk
                stable = 0
                if output.endswith(cfg['prompt']):
                    break
            else:
                stable += 1
                if stable >= 10:
                    break
                time.sleep(0.5)
        except:
            time.sleep(0.5)
    
    log(f"Telnet received: {len(output)} bytes")
    return output

def backup_via_telnet(info, cfg):
    try:
        log(f"Telnet → {info['ip']}:{info['port']}")
        tn = telnetlib.Telnet(info['ip'], info['port'], timeout=30)
        
        tn.read_until(cfg['login_prompt'], timeout=10)
        tn.write(info['username'].encode('ascii') + b"\n")
        
        tn.read_until(cfg['password_prompt'], timeout=10)
        tn.write(info['password'].encode('ascii') + b"\n")
        
        response = tn.read_until(cfg['prompt'], timeout=15)
        
        if cfg.get('enable_prompt') and b'>' in response:
            tn.write(b"enable\n")
            tn.read_until(cfg['enable_prompt'], timeout=5)
            tn.write(info['enable_password'].encode('ascii') + b"\n")
            tn.read_until(cfg['prompt'], timeout=10)
        
        all_output = []
        for cmd in cfg['commands']:
            log(f"Command: {cmd}")
            tn.write(cmd.encode('ascii') + b"\n")
            time.sleep(1)
            output = read_with_pagination(tn, cfg)
            all_output.append(output)
        
        tn.write(cfg['exit_cmd'].encode('ascii') + b"\n")
        time.sleep(0.5)
        tn.close()
        
        return b"\n\n".join(all_output)
    except Exception as e:
        log(f"Telnet failed: {e}")
        return None

def backup_via_ssh(info, cfg):
    """Backup device via SSH"""
    if not SSH_AVAILABLE:
        return None
    
    try:
        log(f"SSH → {info['ip']}:{info.get('port', 22)}")
        
        ssh = paramiko.SSHClient()
        ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        
        ssh.connect(
            hostname=info['ip'],
            port=info.get('port', 22),
            username=info['username'],
            password=info['password'],
            timeout=10,
            look_for_keys=False,
            allow_agent=False
        )
        
        log(f"Login: {info['username']}")
        
        # MikroTik needs shell mode
        if info['vendor_name'] == 'MIKROTIK':
            shell = ssh.invoke_shell(width=200, height=1000)  # Large terminal
            time.sleep(2)
            
            # Read and clear welcome
            welcome = b""
            time.sleep(1)
            while shell.recv_ready():
                welcome += shell.recv(4096)
                time.sleep(0.1)
            log(f"Welcome: {len(welcome)} bytes")
            
            all_output = []
            for cmd in cfg['commands']:
                log(f"Command: {cmd}")
                shell.send(cmd + "\r\n")  # \r\n for MikroTik!
                
                # Wait for command to execute
                output = b""
                started = False
                deadline = time.time() + 90  # 90 seconds!
                last_recv = time.time()
                
                while time.time() < deadline:
                    if shell.recv_ready():
                        try:
                            chunk = shell.recv(8192)
                            if chunk:
                                output += chunk
                                last_recv = time.time()
                                if not started:
                                    log(f"  Started receiving data...")
                                    started = True
                                if len(output) % 10000 < 8192:  # Log every ~10KB
                                    log(f"  Received: {len(output)} bytes...")
                        except:
                            break
                    else:
                        # No data ready - check if we're done
                        idle_time = time.time() - last_recv
                        if started and idle_time > 3:  # 3 seconds idle after data started
                            log(f"  Idle for 3s, assuming done")
                            break
                        time.sleep(0.5)
                
                all_output.append(output)
                log(f"Total received: {len(output)} bytes")
                
                if len(output) == 0:
                    log(f"⚠️ WARNING: No output from command!")
            
            shell.close()
            ssh.close()
            return b"\n\n".join(all_output)
        
        # CISCO/HPE with enable mode
        elif cfg.get('enable_prompt'):
            shell = ssh.invoke_shell()
            time.sleep(1)
            
            # Clear initial output
            shell.recv(65535)
            
            # Send enable command
            shell.send("enable\n")
            time.sleep(1)
            
            # Send enable password
            shell.send(info['enable_password'] + "\n")
            time.sleep(1)
            
            # Clear enable output
            shell.recv(65535)
            
            # Execute commands via shell
            all_output = []
            for cmd in cfg['commands']:
                log(f"Command: {cmd}")
                shell.send(cmd + "\n")
                time.sleep(2)
                
                # Read ALL output
                output = b""
                deadline = time.time() + 30
                while time.time() < deadline:
                    if shell.recv_ready():
                        chunk = shell.recv(65535)
                        output += chunk
                        time.sleep(0.1)
                    else:
                        time.sleep(0.5)
                        if not shell.recv_ready():
                            break
                
                all_output.append(output)
                log(f"Received: {len(output)} bytes")
            
            shell.close()
            ssh.close()
            return b"\n\n".join(all_output)
        
        else:
            # Other vendors - use exec_command (reads until EOF automatically)
            all_output = []
            for cmd in cfg['commands']:
                log(f"Command: {cmd}")
                stdin, stdout, stderr = ssh.exec_command(cmd, timeout=30)
                output = stdout.read()  # Reads ALL output automatically
                all_output.append(output)
                log(f"Received: {len(output)} bytes")
                time.sleep(0.5)
            
            ssh.close()
            return b"\n\n".join(all_output)
            
    except Exception as e:
        log(f"SSH failed: {e}")
        return None

def backup_device(info):
    cfg = VENDOR_COMMANDS.get(info['vendor_name'], VENDOR_COMMANDS['GENERIC'])
    
    try:
        vendor_dir = os.path.join(BACKUP_DIR, info['vendor_name'])
        ip_dir = os.path.join(vendor_dir, info['ip'])
        os.makedirs(ip_dir, exist_ok=True)
        
        combined = None
        
        # Try each credential
        for idx, cred in enumerate(info['credentials'], 1):
            log(f"[TRY {idx}/{len(info['credentials'])}] {cred['username']}")
            
            info['username'] = cred['username']
            info['password'] = cred['password']
            info['enable_password'] = cred.get('enable_password') or cred['password']
            
            device_port = info.get('port', 23)
            
            # Try SSH first (skip if port 23 = Telnet port)
            if SSH_AVAILABLE and device_port != 23:
                log(f"  → SSH (port {device_port})")
                combined = backup_via_ssh(info, cfg)
                if combined and len(combined) > 100:
                    log(f"✅ SUCCESS via SSH with credential #{idx} (id={cred['id']})")
                    info['credential_id'] = cred['id']
                    break
            
            # Telnet
            log(f"  → Telnet (port {device_port})")
            combined = backup_via_telnet(info, cfg)
            
            if combined and len(combined) > 100:
                log(f"✅ SUCCESS via Telnet with credential #{idx} (id={cred['id']})")
                info['credential_id'] = cred['id']
                break
            else:
                log(f"❌ Credential #{idx} failed")
        
        if not combined:
            raise Exception(f"All {len(info['credentials'])} credential(s) failed")
        
        config = combined.decode('utf-8', errors='ignore')
        config = config.replace('--More--', '').replace('---- More ----', '')
        config = config.replace('\x1b[K', '')
        
        lines = [l for l in config.split('\n') 
                if l.strip() and not any(c in l for c in cfg['commands'])]
        config = '\n'.join(lines).strip()
        
        if len(config) < 50:
            raise Exception(f"Config too short: {len(config)} bytes")
        
        log(f"Config: {len(config)} bytes")
        
        timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        ext = 'rsc' if info['vendor_name'] == 'MIKROTIK' else 'cfg'
        filename = f"{info['hostname']}_{timestamp}.{ext}"
        filepath = os.path.join(ip_dir, filename)
        
        with open(filepath, 'w') as f:
            f.write(config)
        
        # Create symlink to latest backup (relative path within same directory)
        symlink = os.path.join(ip_dir, f"{info['hostname']}-latest.{ext}")
        if os.path.lexists(symlink):  # Use lexists to detect broken symlinks
            os.remove(symlink)
        # Symlink should use relative path (just filename, not full path)
        os.symlink(filename, symlink)
        
        # Print filepath for app.py to capture
        print(f"Saved to: {filepath}", flush=True)
        
        # NOTE: Backup history is recorded by app.py, not here!
        # This prevents duplicate entries
        
        log("✅ SUCCESS!")
        return True
    except Exception as e:
        log(f"❌ ERROR: {e}")
        # NOTE: Error is logged by app.py
        return False

if __name__ == '__main__':
    if len(sys.argv) < 2:
        sys.exit(1)
    
    info = get_device_info(sys.argv[1])
    if not info:
        sys.exit(1)
    
    success = backup_device(info)
    sys.exit(0 if success else 1)
