#!/bin/bash
# Database initialization script

DB_FILE="/data/backup_manager.db"

if [ ! -f "$DB_FILE" ]; then
    echo "[DB] Creating new database..."
    sqlite3 "$DB_FILE" < /app/schema.sql
    echo "[DB] Database created!"
else
    echo "[DB] Database exists, checking schema..."
    
    # Check if schedules has new columns
    if ! sqlite3 "$DB_FILE" "PRAGMA table_info(schedules);" | grep -q "vendor_id"; then
        echo "[DB] Migrating schedules table..."
        sqlite3 "$DB_FILE" < /app/migration.sql
        echo "[DB] Migration complete!"
    else
        echo "[DB] Schema is up to date!"
    fi
fi
