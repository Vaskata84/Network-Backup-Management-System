-- ════════════════════════════════════════════════════════════════
-- Network Backup Management System - Complete Schema
-- Version 3.0 - All Fixes Included
-- Vasil Dobchev - supportpc.org
-- With Universal Backup Script Support
-- ════════════════════════════════════════════════════════════════

-- Users table
CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username VARCHAR(50) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    email VARCHAR(100),
    role VARCHAR(20) DEFAULT 'user',
    enabled BOOLEAN DEFAULT 1,
    last_login DATETIME,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- Vendors table
CREATE TABLE IF NOT EXISTS vendors (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name VARCHAR(50) NOT NULL UNIQUE,
    description TEXT,
    default_method VARCHAR(20) DEFAULT 'telnet',
    default_port INTEGER,
    enabled BOOLEAN DEFAULT 1,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- Networks table
CREATE TABLE IF NOT EXISTS networks (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name VARCHAR(100) NOT NULL,
    network_range VARCHAR(50) NOT NULL,
    snmp_community VARCHAR(50) DEFAULT 'public',
    description TEXT,
    enabled BOOLEAN DEFAULT 1,
    auto_scan BOOLEAN DEFAULT 0,
    scan_interval INTEGER DEFAULT 3600,
    last_scan DATETIME,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- Devices table (WITH network_id!)
CREATE TABLE IF NOT EXISTS devices (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    ip_address VARCHAR(15) NOT NULL UNIQUE,
    hostname VARCHAR(100),
    vendor_id INTEGER NOT NULL,
    network_id INTEGER,
    model VARCHAR(100),
    location VARCHAR(200),
    method VARCHAR(20) NOT NULL,
    port INTEGER,
    enabled BOOLEAN DEFAULT 1,
    last_backup DATETIME,
    last_status VARCHAR(20),
    backup_count INTEGER DEFAULT 0,
    notes TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (vendor_id) REFERENCES vendors(id),
    FOREIGN KEY (network_id) REFERENCES networks(id)
);

CREATE INDEX IF NOT EXISTS idx_devices_network_id ON devices(network_id);
CREATE INDEX IF NOT EXISTS idx_devices_vendor_id ON devices(vendor_id);

-- Credentials table
CREATE TABLE IF NOT EXISTS credentials (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name VARCHAR(100) NOT NULL,
    vendor_id INTEGER,
    username VARCHAR(100) NOT NULL,
    password VARCHAR(255) NOT NULL,
    enable_password VARCHAR(255),
    priority INTEGER DEFAULT 0,
    enabled BOOLEAN DEFAULT 1,
    success_count INTEGER DEFAULT 0,
    fail_count INTEGER DEFAULT 0,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (vendor_id) REFERENCES vendors(id)
);

-- Scripts table (for universal backup scripts)
CREATE TABLE IF NOT EXISTS scripts (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name VARCHAR(100) NOT NULL UNIQUE,
    vendor_id INTEGER,
    script_type VARCHAR(20) NOT NULL,
    language VARCHAR(20) NOT NULL,
    content TEXT NOT NULL,
    filename_pattern VARCHAR(200) DEFAULT '{ip}-{date}.cfg',
    commands TEXT,
    enabled BOOLEAN DEFAULT 1,
    test_count INTEGER DEFAULT 0,
    success_count INTEGER DEFAULT 0,
    fail_count INTEGER DEFAULT 0,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (vendor_id) REFERENCES vendors(id)
);

-- Schedules table (Cron jobs)
CREATE TABLE IF NOT EXISTS schedules (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name VARCHAR(100) NOT NULL,
    cron_expression VARCHAR(100) NOT NULL,
    script_id INTEGER NOT NULL,
    vendor_id INTEGER,
    network_id INTEGER,
    device_id INTEGER,
    enabled BOOLEAN DEFAULT 1,
    last_run DATETIME,
    next_run DATETIME,
    run_count INTEGER DEFAULT 0,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (script_id) REFERENCES scripts(id),
    FOREIGN KEY (vendor_id) REFERENCES vendors(id),
    FOREIGN KEY (network_id) REFERENCES networks(id),
    FOREIGN KEY (device_id) REFERENCES devices(id)
);

-- Backup History table
CREATE TABLE IF NOT EXISTS backup_history (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    ip_address VARCHAR(15) NOT NULL,
    hostname VARCHAR(100),
    device_id INTEGER,
    vendor_id INTEGER,
    script_id INTEGER,
    credential_id INTEGER,
    method VARCHAR(20),
    status VARCHAR(20) NOT NULL,
    file_path TEXT,
    file_size INTEGER,
    output TEXT,
    error_message TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (device_id) REFERENCES devices(id),
    FOREIGN KEY (vendor_id) REFERENCES vendors(id),
    FOREIGN KEY (script_id) REFERENCES scripts(id),
    FOREIGN KEY (credential_id) REFERENCES credentials(id)
);

CREATE INDEX IF NOT EXISTS idx_backup_history_ip ON backup_history(ip_address);
CREATE INDEX IF NOT EXISTS idx_backup_history_created ON backup_history(created_at);
CREATE INDEX IF NOT EXISTS idx_backup_history_status ON backup_history(status);

-- Default admin user (password: admin - CHANGE THIS!)
INSERT OR IGNORE INTO users (id, username, password, email, role, enabled)
VALUES (1, 'admin', '8c6976e5b5410415bde908bd4dee15dfb167a9c873fc4bb8a81f6f2ab448a918', 'help@supportpc.org', 'admin', 1);

-- Default vendors (ALL major manufacturers)
INSERT OR IGNORE INTO vendors (id, name, description, default_method, default_port) VALUES
(1, 'MIKROTIK', 'MikroTik RouterOS devices', 'telnet', 23),
(2, 'CISCO', 'Cisco IOS/IOS-XE devices', 'telnet', 23),
(3, 'HUAWEI', 'Huawei VRP network devices', 'telnet', 23),
(4, 'JUNIPER', 'Juniper Networks JunOS', 'ssh', 22),
(5, 'HPE', 'HPE/Aruba/ProCurve switches', 'telnet', 23),
(6, 'DELL', 'Dell/PowerConnect switches', 'telnet', 23),
(7, 'UBIQUITI', 'Ubiquiti EdgeOS/UniFi', 'ssh', 22),
(8, 'GENERIC', 'Generic/Unknown device', 'telnet', 23),
(9, 'D-LINK', 'D-Link switches and routers', 'telnet', 23),
(10, 'TP-LINK', 'TP-Link managed switches', 'telnet', 23),
(11, 'PLANET', 'Planet switches', 'telnet', 23),
(12, 'RUBY', 'Ruby Tech switches', 'telnet', 23),
(13, 'EXTREME', 'Extreme Networks', 'telnet', 23),
(14, 'ALCATEL', 'Alcatel-Lucent OmniSwitch', 'telnet', 23),
(15, 'ZTE', 'ZTE network equipment', 'telnet', 23),
(16, 'NETGEAR', 'Netgear managed switches', 'telnet', 23),
(17, '3COM', '3Com switches (legacy)', 'telnet', 23),
(18, 'ZYXEL', 'ZyXEL switches and routers', 'telnet', 23),
(19, 'FORTINET', 'FortiGate/FortiSwitch', 'ssh', 22),
(20, 'PALO-ALTO', 'Palo Alto Networks', 'ssh', 22);
