#!/usr/bin/env python3
import sys
import os

print("[TEST] Script starting...", flush=True)
print(f"[TEST] Args: {sys.argv}", flush=True)
print(f"[TEST] Working dir: {os.getcwd()}", flush=True)

ip = sys.argv[1] if len(sys.argv) > 1 else "unknown"
print(f"[TEST] IP: {ip}", flush=True)

# Try import
try:
    import telnetlib
    print("[TEST] telnetlib OK", flush=True)
except Exception as e:
    print(f"[TEST] telnetlib ERROR: {e}", flush=True)

try:
    import paramiko
    print("[TEST] paramiko OK", flush=True)
except Exception as e:
    print(f"[TEST] paramiko ERROR: {e}", flush=True)

try:
    import sqlite3
    print("[TEST] sqlite3 OK", flush=True)
except Exception as e:
    print(f"[TEST] sqlite3 ERROR: {e}", flush=True)

# Try database
try:
    conn = sqlite3.connect('/data/backup_manager.db', timeout=30.0)
    print("[TEST] Database connected", flush=True)
    cursor = conn.cursor()
    
    device = cursor.execute('''
        SELECT d.*, v.name as vendor_name
        FROM devices d
        JOIN vendors v ON d.vendor_id = v.id
        WHERE d.ip_address = ?
    ''', (ip,)).fetchone()
    
    if device:
        print(f"[TEST] Device found: {dict(device)}", flush=True)
    else:
        print("[TEST] Device NOT found", flush=True)
        sys.exit(1)
    
    conn.close()
except Exception as e:
    print(f"[TEST] Database ERROR: {e}", flush=True)
    sys.exit(1)

print("[TEST] Script completed successfully!", flush=True)
sys.exit(0)
