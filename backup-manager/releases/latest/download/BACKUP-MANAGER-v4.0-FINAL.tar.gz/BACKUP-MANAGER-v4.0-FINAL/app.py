from flask import Flask, render_template, send_file, request, jsonify, session, redirect, url_for
from datetime import datetime
from apscheduler.schedulers.background import BackgroundScheduler
from apscheduler.triggers.cron import CronTrigger
from functools import wraps
import os, sqlite3, hashlib, subprocess, tempfile, socket, ipaddress
from concurrent.futures import ThreadPoolExecutor, ProcessPoolExecutor, as_completed
from multiprocessing import cpu_count
try:
    from pysnmp.hlapi import *
    SNMP_AVAILABLE = True
except ImportError:
    SNMP_AVAILABLE = False
from datetime import datetime

app = Flask(__name__)
app.secret_key = os.environ.get('SECRET_KEY', 'backup-2025-secure-key')

DB_FILE = '/data/backup_manager.db'
BACKUP_DIR = '/data/SWITCH_BACKUP'
SCRIPTS_DIR = '/data/scripts'

# Performance configuration
MAX_PARALLEL_WORKERS = int(os.environ.get('MAX_WORKERS', '50'))  # Max concurrent backups
WORKER_TIMEOUT = int(os.environ.get('WORKER_TIMEOUT', '120'))     # Timeout per device (seconds)

# Initialize APScheduler
scheduler = BackgroundScheduler()
scheduler.start()

def load_cron_jobs():
    """Load cron jobs from database and schedule them"""
    print("[CRON] Loading cron jobs from database...")
    log_msg("Loading cron jobs from database...")
    db = get_db()
    jobs = db.execute('SELECT * FROM schedules WHERE enabled=1').fetchall()
    
    print(f"[CRON] Found {len(job)} enabled jobs")
    
    # Clear existing jobs
    scheduler.remove_all_jobs()
    
    for job in job:
        try:
            print(f"[CRON] Loading job: {job['name']} - {job['cron_expression']}")
            trigger = CronTrigger.from_crontab(job['cron_expression'])
            scheduler.add_job(
                run_cron_job,
                trigger=trigger,
                args=[job['id']],
                id=f"cron_{job['id']}",
                replace_existing=True,
                max_instances=3  # Allow up to 3 parallel instances
            )
            print(f"[CRON] ✅ Added job {job['id']} to scheduler")
            log_msg(f"Loaded cron job: {job['name']} ({job['cron_expression']})")
        except Exception as e:
            print(f"[CRON] ❌ Error loading job {job['name']}: {e}")
            log_msg(f"Error loading cron job {job['name']}: {e}")
    
    print(f"[CRON] Scheduler now has {len(scheduler.get_jobs())} jobs")
    for scheduled_job in scheduler.get_jobs():
        print(f"[CRON]   - {scheduled_job.id}: next run at {scheduled_job.next_run_time}")

def run_script_on_device(script_id, ip_address):
    """Execute a script on a device"""
    db = get_db()
    
    # Get script
    script = db.execute('SELECT * FROM scripts WHERE id=?', (script_id,)).fetchone()
    if not script:
        raise Exception(f"Script {script_id} not found")
    
    # Get device
    device = db.execute('SELECT * FROM devices WHERE ip_address=?', (ip_address,)).fetchone()
    if not device:
        raise Exception(f"Device {ip_address} not found")
    
    print(f"[SCRIPT] Executing '{script['name']}' on {ip_address}", flush=True)
    
    # Get ALL credentials for vendor
    credentials = db.execute('''
        SELECT id, username, password, enable_password, priority
        FROM credentials 
        WHERE vendor_id = ? AND enabled = 1
        ORDER BY priority DESC
    ''', (device['vendor_id'],)).fetchall()
    
    if credentials:
        print(f"[SCRIPT] Loaded {len(credentials)} credential(s)", flush=True)
    
    # Create temp script file
    script_file = f"{SCRIPTS_DIR}/temp_script_{script_id}_{ip_address.replace('.', '_')}.py"
    with open(script_file, 'w') as f:
        f.write(script['content'])
    
    os.chmod(script_file, 0o755)
    
    try:
        # Execute script with suppressed warnings
        import os as os_module
        import json
        script_env = os_module.environ.copy()
        script_env['PYTHONWARNINGS'] = 'ignore'
        
        # Pass credentials as JSON
        if credentials:
            credentials_list = [dict(c) for c in credentials]
            script_env['CREDENTIALS_JSON'] = json.dumps(credentials_list)
        
        result = subprocess.run(
            ['python3', '-u', script_file, ip_address],  # -u = unbuffered!
            capture_output=True,
            text=True,
            timeout=60,
            env=script_env
        )
        
        # Save to backup history
        success = result.returncode == 0
        status = 'success' if success els 'failed'
        
        # Try to find output file
        file_path = None
        output_lines = result.stdout.split('\n')
        for line in output_lines:
            if 'Saved to:' in line or 'saved to' in line.lower():
                parts = line.split(':')
                if len(parts) > 1:
                    file_path = parts[-1].strip()
                    print(f"[SCRIPT] Found file_path from output: {file_path}", flush=True)
                    break
        
        # If no file found, check backup dir (search in vendor subdirs)
        if not file_path:
            import glob
            # Try with vendor subdir first
            vendor_name = device.get('vendor_name', 'GENERIC') if 'vendor_name' in device.keys() else 'GENERIC'
            pattern1 = f"{BACKUP_DIR}/*/{ip_address}/*.*"
            pattern2 = f"{BACKUP_DIR}/{vendor_name}/{ip_address}/*.*"
            pattern3 = f"{BACKUP_DIR}/**/{ip_address.replace('.', '_')}*.*"
            
            print(f"[SCRIPT] Searching for backup file with patterns...", flush=True)
            for pattern in [pattern1, pattern2, pattern3]:
                files = sorted(glob.glob(pattern, recursive=True), key=os.path.getmtime, reverse=True)
                if files:
                    file_path = files[0]
                    print(f"[SCRIPT] Found file via glob: {file_path}", flush=True)
                    break
        
        if not file_path:
            print(f"[SCRIPT] ⚠️ WARNING: No file_path found!", flush=True)
        
        file_size = os.path.getsize(file_path) if file_path and os.path.exists(file_path) else 0
        
        if file_path and os.path.exists(file_path):
            print(f"[SCRIPT] ✅ File verified: {file_path} ({file_size} bytes)", flush=True)
        else:
            print(f"[SCRIPT] ❌ File NOT found or path is None", flush=True)
        
        # Get device details for backup history
        method = device["method"] if device["method"] else "telnet"
        hostname = device["hostname"] if device["hostname"] else f"device-{ip_address.split('.')[-1]}"
        
        db.execute('''INSERT INTO backup_history 
                     (ip_address, hostname, device_id, vendor_id, script_id, method, status, file_path, file_size, output)
                     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)''',
                  (ip_address, hostname, device['id'], device['vendor_id'], script_id, 
                   method, status, file_path, file_size, result.stdout[:1000]))
        
        # Update success counters
        if success:
            db.execute('UPDATE scripts SET success_count = success_count + 1 WHERE id = ?', (script_id,))
            
            # Try to extract credential_id from output
            for line in result.stdout.split('\n'):
                if 'id=' in line and 'SUCCESS' in line:
                    try:
                        cred_id = int(line.split('id=')[1].split(')')[0])
                        db.execute('UPDATE credentials SET success_count = success_count + 1 WHERE id = ?', (cred_id,))
                        break
                    except:
                        pass
        
        db.commit()
        
        print(f"[SCRIPT] Completed on {ip_address}: {status}")
        
        if not success:
            raise Exception(f"Script failed with exit code {result.returncode}: {result.stderr}")
            
    except subprocess.TimeoutExpired:
        raise Exception("Script execution timeout (60s)")
    finally:
        # Always clean up temp file
        if os.path.exists(script_file):
            try:
                os.remove(script_file)
            except:
                pass  # Ignore cleanup errors

def run_cron_job(job_id):
    """Execute a cron job"""
    print(f"\n{'='*60}")
    print(f"[CRON] ⚡ EXECUTING JOB {job_id} at {datetime.now()}")
    print(f"{'='*60}")
    log_msg(f"[CRON] Running job {job_id}")
    
    db = get_db()
    
    job = db.execute('SELECT * FROM schedules WHERE id=?', (job_id,)).fetchone()
    if not job:
        print(f"[CRON] ❌ Job {job_id} not found in database!")
        log_msg(f"[CRON] Job {job_id} not found")
        return
    
    print(f"[CRON] Job details:")
    print(f"  - Name: {job['name']}")
    print(f"  - Expression: {job['cron_expression']}")
    print(f"  - Script ID: {job['script_id']}")
    print(f"  - Device ID: {job['device_id']}")
    
    # Get script
    script = db.execute('SELECT * FROM scripts WHERE id=?', (job['script_id'],)).fetchone()
    if not script:
        print(f"[CRON] ❌ Script {job['script_id']} not found!")
        log_msg(f"[CRON] Script not found for job {job_id}")
        return
    
    print(f"[CRON] Script: {script['name']}")
    
    # Get target devices
    devices = []
    if job['device_id']:
        print(f"[CRON] Target: Single device (ID={job['device_id']})")
        devices = db.execute('SELECT * FROM devices WHERE id=? AND enabled=1', (job['device_id'],)).fetchall()
    elif job['network_id']:
        print(f"[CRON] Target: Network (ID={job['network_id']})")
        devices = db.execute('SELECT * FROM devices WHERE network_id=? AND enabled=1', (job['network_id'],)).fetchall()
    elif job['vendor_id']:
        print(f"[CRON] Target: Vendor (ID={job['vendor_id']})")
        devices = db.execute('SELECT * FROM devices WHERE vendor_id=? AND enabled=1', (job['vendor_id'],)).fetchall()
    else:
        print(f"[CRON] Target: All devices")
        devices = db.execute('SELECT * FROM devices WHERE enabled=1').fetchall()
    
    print(f"[CRON] Found {len(devices)} target device(s)")
    for d in devices:
        print(f"  - {d['ip_address']} ({d['hostname']})")
    
    log_msg(f"[CRON] Job {job['name']}: Running on {len(devices)} devices")
    
    # Determine optimal worker count
    # Use 50% of CPU cores or max 50 workers (whichever is smaller)
    max_workers = min(max(cpu_count() // 2, 10), 50)
    
    # Adjust workers based on device count
    if len(devices) < 10:
        workers = len(devices)  # No point having more workers than devices
    elif len(devices) < 100:
        workers = min(10, max_workers)
    elif len(devices) < 1000:
        workers = min(25, max_workers)
    else:
        workers = max_workers  # Use maximum for large batches
    
    print(f"[CRON] 🚀 Using {workers} parallel workers for {len(devices)} devices")
    log_msg(f"[CRON] Using {workers} parallel workers")
    
    # Execute script on devices in parallel using ThreadPoolExecutor
    # (ThreadPoolExecutor is better than ProcessPoolExecutor for I/O-bound tasks like network backups)
    success_count = 0
    failed_count = 0
    
    with ThreadPoolExecutor(max_workers=workers) as executor:
        # Submit all tasks
        future_to_device = {
            executor.submit(run_script_on_device, script['id'], device['ip_address']): device 
            for device in devices
        }
        
        # Process completed tasks as they finish
        for future in as_completed(future_to_device):
            device = future_to_device[future]
            try:
                result = future.result()
                print(f"[CRON] ✅ Completed {device['ip_address']}")
                success_count += 1
            except Exception as e:
                print(f"[CRON] ❌ Error on {device['ip_address']}: {e}")
                log_msg(f"[CRON] Error on {device['ip_address']}: {e}")
                failed_count += 1
    
    print(f"[CRON] 📊 Results: {success_count} success, {failed_count} failed")
    log_msg(f"[CRON] Results: {success_count} success, {failed_count} failed")
    
    # Update last run time
    db.execute('UPDATE schedules SET last_run=CURRENT_TIMESTAMP WHERE id=?', (job_id,))
    db.commit()
    
    print(f"[CRON] ✅ Job {job['name']} completed!")
    print(f"{'='*60}\n")
    log_msg(f"[CRON] Job {job['name']} completed")

def log_msg(msg):
    """Log message to file and console"""
    print(msg)
    with open('/data/logs/cron.log', 'a') as f:
        f.write(f"{datetime.now()}: {msg}\n")

def get_db():
    conn = sqlite3.connect(DB_FILE, timeout=30.0)
    conn.row_factory = sqlite3.Row
    conn.execute('PRAGMA journal_mode=WAL')
    conn.execute('PRAGMA busy_timeout=30000')
    return conn


# ═══════════════════════════════════════════════════════════════════
# NETWORK SCANNING - PING-BASED WITH SNMP HOSTNAME DETECTION
# ═══════════════════════════════════════════════════════════════════

def check_port(ip, port, timeout=0.3):
    """Check if TCP port is open"""
    try:
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sock.settimeout(timeout)
        result = sock.connect_ex((ip, port))
        sock.close()
        return result == 0
    except:
        return False

def get_snmp_hostname(ip, community='public'):
    """Get hostname via SNMP (sysName)"""
    if not SNMP_AVAILABLE:
        return None
    
    try:
        iterator = getCmd(
            SnmpEngine(),
            CommunityData(community, mpModel=1),
            UdpTransportTarget((ip, 161), timeout=0.5, retries=0),
            ContextData(),
            ObjectType(ObjectIdentity('SNMPv2-MIB', 'sysName', 0))
        )
        
        errorIndication, errorStatus, errorIndex, varBinds = next(iterator)
        
        if not errorIndication and not errorStatus and len(varBinds) > 0:
            sysname = str(varBinds[0][1])
            if sysname and len(sysname) > 2 and sysname != 'None':
                print(f"[SNMP] Got hostname from {ip}: {sysname}")
                return sysname[:50]
    except Exception as e:
        print(f"[SNMP] Error from {ip}: {e}")
    
    return None

def get_hostname(ip, community='public'):
    """Get hostname from SNMP, DNS, or generate"""
    # Try SNMP first (best!)
    hostname = get_snmp_hostname(ip, community)
    if hostname:
        return hostname
    
    # Try DNS
    try:
        hostname = socket.gethostbyaddr(ip)[0]
        if hostname and hostname != ip:
            hostname = hostname.split('.')[0]
            if len(hostname) > 3 and not hostname.startswith('192-'):
                return hostname[:50]
    except:
        pass
    
    # Generate from IP
    return f"device-{ip.split('.')[-1]}"

def scan_single_ip(ip, community='public'):
    """Scan single IP - PORT SCAN ONLY (NO PING!)"""
    # Check MANY ports for maximum discovery!
    telnet = check_port(ip, 23)
    ssh = check_port(ip, 22)
    winbox = check_port(ip, 8291)
    api = check_port(ip, 8728)
    snmp = check_port(ip, 161)
    http = check_port(ip, 80)
    https = check_port(ip, 443)
    
    # If NO ports open, skip this IP
    if not any([telnet, ssh, winbox, api, snmp, http, https]):
        return None
    
    # Determine best method (priority order)
    if telnet:
        method, port = 'telnet', 23
    elif ssh:
        method, port = 'ssh', 22
    elif winbox:
        method, port = 'winbox', 8291
    elif api:
        method, port = 'api', 8728
    elif snmp:
        method, port = 'snmp', 161
    elif http:
        method, port = 'http', 80
    elif https:
        method, port = 'https', 443
    
    # Get hostname (SNMP > DNS > generated)
    hostname = get_hostname(ip, community)
    
    # Detect vendor via SNMP sysDescr
    vendor_id = 8  # Default: GENERIC
    try:
        import sys
        print(f"[SCAN] Attempting SNMP detection for {ip}...", flush=True)
        from pysnmp.hlapi import getCmd, SnmpEngine, CommunityData, UdpTransportTarget, ContextData, ObjectType, ObjectIdentity
        
        print(f"[SCAN] pysnmp imported successfully", flush=True)
        
        # Get sysDescr (1.3.6.1.2.1.1.1.0)
        iterator = getCmd(
            SnmpEngine(),
            CommunityData(community),
            UdpTransportTarget((ip, 161), timeout=2, retries=0),
            ContextData(),
            ObjectType(ObjectIdentity('SNMPv2-MIB', 'sysDescr', 0))
        )
        
        print(f"[SCAN] SNMP query sent to {ip}", flush=True)
        
        errorIndication, errorStatus, errorIndex, varBinds = next(iterator)
        
        if errorIndication:
            print(f"[SCAN] SNMP error: {errorIndication}", flush=True)
        elif errorStatus:
            print(f"[SCAN] SNMP status error: {errorStatus}", flush=True)
        else:
            sys_descr = str(varBinds[0][1]).lower()
            print(f"[SCAN] {ip} sysDescr: {sys_descr[:80]}", flush=True)
            
            # Detect vendor from sysDescr
            if 'mikrotik' in sys_descr or 'routeros' in sys_descr:
                vendor_id = 1  # MIKROTIK
            elif 'cisco' in sys_descr or 'ios' in sys_descr:
                vendor_id = 2  # CISCO  
            elif 'huawei' in sys_descr or 'vrp' in sys_descr:
                vendor_id = 3  # HUAWEI
            elif 'juniper' in sys_descr or 'junos' in sys_descr:
                vendor_id = 4  # JUNIPER
            elif 'hpe' in sys_descr or 'aruba' in sys_descr or 'procurve' in sys_descr:
                vendor_id = 5  # HPE
            elif 'dell' in sys_descr or 'powerconnect' in sys_descr:
                vendor_id = 6  # DELL
            elif 'ubiquiti' in sys_descr or 'edgeos' in sys_descr or 'unifi' in sys_descr:
                vendor_id = 7  # UBIQUITI
            elif 'd-link' in sys_descr or 'dlink' in sys_descr:
                vendor_id = 9  # D-LINK
            elif 'tp-link' in sys_descr or 'tplink' in sys_descr:
                vendor_id = 10  # TP-LINK
            elif 'planet' in sys_descr:
                vendor_id = 11  # PLANET
            elif 'ruby' in sys_descr:
                vendor_id = 12  # RUBY
            elif 'extreme' in sys_descr:
                vendor_id = 13  # EXTREME
            elif 'alcatel' in sys_descr or 'omniswitch' in sys_descr:
                vendor_id = 14  # ALCATEL
            elif 'zte' in sys_descr:
                vendor_id = 15  # ZTE
            elif 'netgear' in sys_descr:
                vendor_id = 16  # NETGEAR
            elif '3com' in sys_descr:
                vendor_id = 17  # 3COM
            elif 'zyxel' in sys_descr:
                vendor_id = 18  # ZYXEL
            elif 'fortinet' in sys_descr or 'fortigate' in sys_descr:
                vendor_id = 19  # FORTINET
            elif 'palo alto' in sys_descr:
                vendor_id = 20  # PALO-ALTO
            
            print(f"[SCAN] {ip}: Detected vendor_id={vendor_id}", flush=True)
    except ImportError as e:
        print(f"[SCAN] ❌ pysnmp NOT INSTALLED: {e}", flush=True)
        print(f"[SCAN] Run: pip install pysnmp==4.4.12", flush=True)
    except Exception as e:
        print(f"[SCAN] SNMP failed for {ip}: {e}", flush=True)
    
    return {
        'ip': ip,
        'hostname': hostname,
        'method': method,
        'port': port,
        'vendor_id': vendor_id
    }

def scan_network(network_id):
    """Scan entire network - PING-BASED with SNMP"""
    db = get_db()
    net = db.execute('SELECT * FROM networks WHERE id=?', (network_id,)).fetchone()
    
    if not net:
        return {'success': False, 'error': 'Network not found'}
    
    try:
        community = net['snmp_community'] if net['snmp_community'] else 'public'
    except (KeyError, TypeError):
        community = 'public'
    print(f"[SCAN] ════════════════════════════════════════")
    print(f"[SCAN] PORT SCAN (NO PING): {net['network_range']}")
    print(f"[SCAN] SNMP Community: {community}")
    print(f"[SCAN] ════════════════════════════════════════")
    
    try:
        cidr = ipaddress.IPv4Network(net['network_range'], strict=False)
        ips = [str(ip) for ip in cidr]
        
        print(f"[SCAN] Scanning {len(ips)} IPs, checking 7 ports each...")
        
        discovered = []
        
        with ThreadPoolExecutor(max_workers=150) as executor:
            futures = {executor.submit(scan_single_ip, ip, community): ip for ip in ips}
                result = future.result()
                if result:
                    discovered.append(result)
                    print(f"[SCAN] ✓ {result['ip']} ({result['hostname']}) {result['method']}")
        
        print(f"[SCAN] Found {len(discovered)} alive devices!")
        
        added = updated = 0
        for d in discovered:
            existing = db.execute('SELECT id FROM devices WHERE ip_address=?', (d['ip'],)).fetchone()
            if existing:
                db.execute('UPDATE devices SET hostname=?, method=?, port=?, vendor_id=?, network_id=?, updated_at=CURRENT_TIMESTAMP WHERE ip_address=?',
                          (d['hostname'], d['method'], d['port'], d.get('vendor_id', 8), network_id, d['ip']))
                updated += 1
            else:
                db.execute('INSERT INTO devices (ip_address, hostname, vendor_id, network_id, method, port, enabled) VALUES (?, ?, ?, ?, ?, ?, 1)',
                          (d['ip'], d['hostname'], d.get('vendor_id', 8), network_id, d['method'], d['port']))
                added += 1
        
        db.execute('UPDATE networks SET last_scan=CURRENT_TIMESTAMP WHERE id=?', (network_id,))
        db.commit()
        
        print(f"[SCAN] Complete! Added {added}, Updated {updated}")
        return {'success': True, 'discovered': len(discovered), 'added': added, 'updated': updated}
        
    except Exception as e:
        print(f"[SCAN] ERROR: {e}")
        import traceback
        traceback.print_exc()
        return {'success': False, 'error': str(e)}


def init_db():
    conn = sqlite3.connect(DB_FILE, timeout=30.0)
    if not os.path.exists(DB_FILE) or os.path.getsize(DB_FILE) == 0:
        with open('schema.sql', 'r') as f:
            conn.executescript(f.read())
        conn.commit()
    conn.execute('PRAGMA journal_mode=WAL')
    conn.close()
    print("[DB] Database initialized with WAL mode", flush=True)

def login_required(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        if not session.get('logged_in'):
            return redirect(url_for('login'))
        return f(*args, **kwargs)
    return decorated

def admin_required(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        if session.get('role') != 'admin':
            return redirect(url_for('index'))
        return f(*args, **kwargs)
    return decorated

# AUTH
@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')
        password_hash = hashlib.sha256(password.encode()).hexdigest()
        db = get_db()
        user = db.execute('SELECT * FROM users WHERE username=? AND password=? AND enabled=1', (username, password_hash)).fetchone()
        if user:
            session['logged_in'] = True
            session['username'] = user['username']
            session['user_id'] = user['id']
            session['role'] = user['role']
            db.execute('UPDATE users SET last_login=CURRENT_TIMESTAMP WHERE id=?', (user['id'],))
            db.commit()
            return redirect(url_for('admin_dashboard'))
        return render_template('login.html', error='Invalid credentials')
    return render_template('login.html')

@app.route('/logout')
def logout():
    session.clear()
    return redirect(url_for('login'))

# HOME
@app.route('/')
@login_required
def index():
    db = get_db()
    search_query = request.args.get('search', '').strip()  # Changed from 'ip' to 'search'
    
    query = '''
        SELECT 
            bh.id,
            bh.ip_address,
            d.hostname,
            v.name as vendor_name,
            bh.status,
            bh.file_size,
            bh.file_path,
            bh.method,
            bh.created_at
        FROM backup_history bh
        LEFT JOIN devices d ON bh.ip_address = d.ip_address
        LEFT JOIN vendors v ON bh.vendor_id = v.id
        WHERE 1=1
    '''
    params = []
    
    if search_query:
        # Search by IP, hostname, OR vendor
        query += ''' AND (
            bh.ip_address LIKE ? OR 
            d.hostname LIKE ? OR 
            v.name LIKE ?
        )'''
        search_param = f'%{search_query}%'
        params.extend([search_param, search_param, search_param])
    
    query += ' ORDER BY bh.created_at DESC LIMIT 100'
    
    backups = db.execute(query, params).fetchall()
    total_backups = db.execute('SELECT COUNT(*) as c FROM backup_history').fetchone()['c']
    success_backups = db.execute('SELECT COUNT(*) as c FROM backup_history WHERE status="success"').fetchone()['c']
    
    # Check if user is admin
    is_admin = session.get('role') == 'admin'
    
    return render_template('index.html', backups=backups, total_backups=total_backups, 
                         success_backups=success_backups, search_query=search_query, is_admin=is_admin)

# DASHBOARD
@app.route('/admin/dashboard')
@admin_required
def admin_dashboard():
    db = get_db()
    stats = {
        'devices': db.execute('SELECT COUNT(*) as c FROM devices').fetchone()['c'],
        'scripts': db.execute('SELECT COUNT(*) as c FROM scripts').fetchone()['c'],
        'networks': db.execute('SELECT COUNT(*) as c FROM networks').fetchone()['c'],
        'users': db.execute('SELECT COUNT(*) as c FROM users').fetchone()['c'],
        'vendors': db.execute('SELECT COUNT(*) as c FROM vendors').fetchone()['c'],
        'credentials': db.execute('SELECT COUNT(*) as c FROM credentials').fetchone()['c'],
        'total_backups': db.execute('SELECT COUNT(*) as c FROM backup_history').fetchone()['c'],
        'success_backups': db.execute('SELECT COUNT(*) as c FROM backup_history WHERE status="success"').fetchone()['c'],
        'failed_backups': db.execute('SELECT COUNT(*) as c FROM backup_history WHERE status="failed"').fetchone()['c']
    }
    recent = db.execute('''
        SELECT bh.*, v.name as vendor_name 
        FROM backup_history bh 
        LEFT JOIN vendors v ON bh.vendor_id = v.id 
        ORDER BY bh.created_at DESC LIMIT 10
    ''').fetchall()
    return render_template('admin_dashboard.html', stats=stats, recent_backups=recent)

# USERS
@app.route('/admin/users')
@admin_required
def admin_users():
    db = get_db()
    users = db.execute('SELECT * FROM users ORDER BY username').fetchall()
    return render_template('admin_users.html', users=users)

@app.route('/api/admin/users/add', methods=['POST'])
@admin_required
def api_add_user():
    try:
        data = request.get_json()
        password_hash = hashlib.sha256(data['password'].encode()).hexdigest()
        db = get_db()
        db.execute('INSERT INTO users (username, password, email, role) VALUES (?, ?, ?, ?)',
                   (data['username'], password_hash, data.get('email'), data['role']))
        db.commit()
        return jsonify({'success': True})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)})

@app.route('/api/admin/users/toggle/<int:user_id>', methods=['POST'])
@admin_required
def api_toggle_user(user_id):
    try:
        db = get_db()
        user = db.execute('SELECT * FROM users WHERE id=?', (user_id,)).fetchone()
        new_state = 0 if user['enabled'] else 1
        db.execute('UPDATE users SET enabled=? WHERE id=?', (new_state, user_id))
        db.commit()
        return jsonify({'success': True})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)})

@app.route('/api/admin/users/delete/<int:user_id>', methods=['DELETE'])
@admin_required
def api_delete_user(user_id):
    try:
        db = get_db()
        db.execute('DELETE FROM users WHERE id=?', (user_id,))
        db.commit()
        return jsonify({'success': True})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)})

# VENDORS
@app.route('/admin/vendors')
@admin_required
def admin_vendors():
    db = get_db()
    vendors = db.execute('SELECT * FROM vendors ORDER BY name').fetchall()
    return render_template('admin_vendors.html', vendors=vendors)

@app.route('/api/admin/vendors/add', methods=['POST'])
@admin_required
def api_add_vendor():
    try:
        data = request.get_json()
        db = get_db()
        db.execute('INSERT INTO vendors (name, description, default_method, default_port) VALUES (?, ?, ?, ?)',
                   (data['name'].upper(), data.get('description', ''), data['default_method'], data.get('default_port')))
        db.commit()
        return jsonify({'success': True})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)})

@app.route('/api/admin/vendors/toggle/<int:vendor_id>', methods=['POST'])
@admin_required
def api_toggle_vendor(vendor_id):
    try:
        db = get_db()
        vendor = db.execute('SELECT * FROM vendors WHERE id=?', (vendor_id,)).fetchone()
        new_state = 0 if vendor['enabled'] else 1
        db.execute('UPDATE vendors SET enabled=? WHERE id=?', (new_state, vendor_id))
        db.commit()
        return jsonify({'success': True})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)})

# DEVICES
@app.route('/admin/devices')
@admin_required
def admin_devices():
    db = get_db()
    devices = db.execute('SELECT d.*, v.name as vendor_name, n.name as network_name FROM devices d JOIN vendors v ON d.vendor_id=v.id LEFT JOIN networks n ON d.network_id=n.id ORDER BY d.ip_address').fetchall()
    vendors = db.execute('SELECT * FROM vendors WHERE enabled=1 ORDER BY name').fetchall()
    networks = db.execute('SELECT * FROM networks WHERE enabled=1 ORDER BY name').fetchall()
    methods = ['telnet', 'ssh', 'tftp']
    return render_template('admin_devices.html', devices=devices, vendors=vendors, networks=networks, methods=methods)

@app.route('/api/admin/devices/add', methods=['POST'])
@admin_required
def api_add_device():
    try:
        data = request.get_json()
        db = get_db()
        network_id = data.get('network_id') if data.get('network_id') != '' else None
        db.execute('INSERT INTO devices (ip_address, hostname, vendor_id, network_id, model, location, method, port) VALUES (?, ?, ?, ?, ?, ?, ?, ?)',
                   (data['ip_address'], data.get('hostname', ''), data['vendor_id'], network_id, data.get('model', ''), data.get('location', ''), data['method'], data.get('port')))
        db.commit()
        return jsonify({'success': True})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)})

@app.route('/api/admin/devices/toggle/<int:device_id>', methods=['POST'])
@admin_required
def api_toggle_device(device_id):
    try:
        db = get_db()
        device = db.execute('SELECT * FROM devices WHERE id=?', (device_id,)).fetchone()
        new_state = 0 if device['enabled'] else 1
        db.execute('UPDATE devices SET enabled=? WHERE id=?', (new_state, device_id))
        db.commit()
        return jsonify({'success': True})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)})

@app.route('/api/admin/devices/delete/<int:device_id>', methods=['DELETE'])
@admin_required
def api_delete_device(device_id):
    try:
        db = get_db()
        db.execute('DELETE FROM devices WHERE id=?', (device_id,))
        db.commit()
        return jsonify({'success': True})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)})

@app.route("/api/admin/devices/update/<int:device_id>", methods=["POST"])
@admin_required
def api_update_device(device_id):
    try:
        data = request.get_json()
        db = get_db()
        db.execute("UPDATE devices SET ip_address=?, hostname=?, vendor_id=?, method=?, port=?, location=? WHERE id=?",
                   (data["ip_address"], data.get("hostname", ""), data["vendor_id"], 
                    data["method"], data.get("port"), data.get("location", ""), device_id))
        db.commit()
        return jsonify({"success": True})
    except Exception as e:
        return jsonify({"success": False, "error": str(e)})
    try:
        db = get_db()
        db.execute('DELETE FROM devices WHERE id=?', (device_id,))
        db.commit()
        return jsonify({'success': True})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)})

# CREDENTIALS
@app.route('/admin/credentials')
@admin_required
def admin_credentials():
    db = get_db()
    credentials = db.execute('SELECT c.*, v.name as vendor_name FROM credentials c LEFT JOIN vendors v ON c.vendor_id=v.id ORDER BY c.vendor_id, c.priority DESC').fetchall()
    vendors = db.execute('SELECT * FROM vendors WHERE enabled=1 ORDER BY name').fetchall()
    return render_template('admin_credentials.html', credentials=credentials, vendors=vendors)

@app.route('/api/admin/credentials/add', methods=['POST'])
@admin_required
def api_add_credential():
    try:
        data = request.get_json()
        db = get_db()
        vendor_id = data.get('vendor_id') if data.get('vendor_id') != '' else None
        db.execute('INSERT INTO credentials (name, vendor_id, username, password, enable_password, priority) VALUES (?, ?, ?, ?, ?, ?)',
                   (data['name'], vendor_id, data['username'], data['password'], data.get('enable_password', ''), data.get('priority', 0)))
        db.commit()
        return jsonify({'success': True})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)})

@app.route('/admin/device/<int:device_id>/backups')
@login_required
def device_backups(device_id):
    """Show all backups for a specific device"""
    db = get_db()
    
    # Get device info
    device = db.execute('''
        SELECT d.*, v.name as vendor_name
        FROM devices d
        JOIN vendors v ON d.vendor_id = v.id
        WHERE d.id = ?
    ''', (device_id,)).fetchone()
    
    if not device:
        return "Device not found", 404
    
    # Get all backups for this device
    backups = db.execute('''
        SELECT DISTINCT
            bh.*,
            s.name as script_name,
            c.username
        FROM backup_history bh
        LEFT JOIN scripts s ON bh.script_id = s.id
        LEFT JOIN credentials c ON bh.credential_id = c.id
        WHERE bh.device_id = ?
        ORDER BY bh.created_at DESC
        LIMIT 100
    ''', (device_id,)).fetchall()
    
    # Statistics
    total = len(backups)
    success = len([b for b in backups if b['status'] == 'success'])
    failed = total - success
    
    return render_template('device_backups.html', 
                         device=device, 
                         backups=backups,
                         total=total,
                         success=success,
                         failed=failed)
    try:
        data = request.get_json()
        db = get_db()
        vendor_id = data.get('vendor_id') if data.get('vendor_id') != '' else None
        db.execute('INSERT INTO credentials (name, vendor_id, username, password, enable_password, priority) VALUES (?, ?, ?, ?, ?, ?)',
                   (data['name'], vendor_id, data['username'], data['password'], data.get('enable_password', ''), data.get('priority', 0)))
        db.commit()
        return jsonify({'success': True})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)})

@app.route('/api/admin/credentials/delete/<int:cred_id>', methods=['DELETE'])
@admin_required
def api_delete_credential(cred_id):
    try:
        db = get_db()
        db.execute('DELETE FROM credentials WHERE id=?', (cred_id,))
        db.commit()
        return jsonify({'success': True})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)})

# NETWORKS

@app.route('/api/admin/networks/scan/<int:network_id>', methods=['POST'])
@admin_required
def api_scan_network(network_id):
    """Start network scan in background"""
    try:
        # Check if network exists
        db = get_db()
        net = db.execute('SELECT * FROM networks WHERE id=?', (network_id,)).fetchone()
        if not net:
            return jsonify({'success': False, 'error': 'Network not found'})
        
        # Start scan in background thread
        from threading import Thread
        scan_thread = Thread(target=scan_network, args=(network_id,), daemon=True)
        scan_thread.start()
        
        print(f"[SCAN] Started background scan for network {network_id}")
        return jsonify({
            'success': True, 
            'message': f'Scan started for {net["network_range"]}. Check logs for progress.',
            'background': True
        })
    except Exception as e:
        import traceback
        traceback.print_exc()
        return jsonify({'success': False, 'error': str(e)})


@app.route('/admin/networks')
@admin_required
def admin_networks():
    db = get_db()
    networks = db.execute('SELECT n.*, (SELECT COUNT(*) FROM devices WHERE network_id=n.id) as device_count FROM networks n ORDER BY name').fetchall()
    return render_template('admin_networks.html', networks=networks)

@app.route('/api/admin/networks/add', methods=['POST'])
@admin_required
def api_add_network():
    try:
        data = request.get_json()
        db = get_db()
        db.execute('INSERT INTO networks (name, network_range, snmp_community, description) VALUES (?, ?, ?, ?)',
                   (data['name'], data['network_range'], data.get('snmp_community', 'public'), data.get('description', '')))
        db.commit()
        return jsonify({'success': True})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)})

@app.route('/api/admin/networks/toggle/<int:network_id>', methods=['POST'])
@admin_required
def api_toggle_network(network_id):
    try:
        db = get_db()
        network = db.execute('SELECT * FROM networks WHERE id=?', (network_id,)).fetchone()
        new_state = 0 if network['enabled'] else 1
        db.execute('UPDATE networks SET enabled=? WHERE id=?', (new_state, network_id))
        db.commit()
        return jsonify({'success': True})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)})

@app.route('/api/admin/networks/delete/<int:network_id>', methods=['DELETE'])
@admin_required
def api_delete_network(network_id):
    try:
        db = get_db()
        db.execute('DELETE FROM networks WHERE id=?', (network_id,))
        db.commit()
        return jsonify({'success': True})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)})

# SCRIPTS
@app.route('/admin/scripts')
@admin_required
def admin_scripts():
    db = get_db()
    scripts = db.execute('SELECT s.*, v.name as vendor_name FROM scripts s LEFT JOIN vendors v ON s.vendor_id=v.id ORDER BY s.name').fetchall()
    return render_template('admin_scripts.html', scripts=scripts)

@app.route('/admin/scripts/create')
@admin_required
def admin_scripts_create():
    db = get_db()
    vendors = db.execute('SELECT * FROM vendors WHERE enabled=1 ORDER BY name').fetchall()
    return render_template('admin_script_editor.html', script=None, vendors=vendors)

@app.route('/admin/scripts/edit/<int:script_id>')
@admin_required
def admin_scripts_edit(script_id):
    db = get_db()
    script = db.execute('SELECT * FROM scripts WHERE id=?', (script_id,)).fetchone()
    vendors = db.execute('SELECT * FROM vendors WHERE enabled=1 ORDER BY name').fetchall()
    return render_template('admin_script_editor.html', script=script, vendors=vendors)

@app.route('/api/admin/scripts/add', methods=['POST'])
@admin_required
def api_add_script():
    try:
        data = request.get_json()
        db = get_db()
        vendor_id = data.get('vendor_id') if data.get('vendor_id') != '' else None
        db.execute('INSERT INTO scripts (name, vendor_id, script_type, language, content, filename_pattern, commands) VALUES (?, ?, ?, ?, ?, ?, ?)',
                   (data['name'], vendor_id, data.get('script_type', 'backup'), data['language'], data['content'], 
                    data.get('filename_pattern', '{ip}-{date}.cfg'), data.get('commands', '')))
        db.commit()
        return jsonify({'success': True, 'script_id': db.execute('SELECT last_insert_rowid()').fetchone()[0]})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)})

@app.route('/api/admin/scripts/update/<int:script_id>', methods=['POST'])
@admin_required
def api_update_script(script_id):
    try:
        data = request.get_json()
        db = get_db()
        vendor_id = data.get('vendor_id') if data.get('vendor_id') != '' else None
        db.execute('UPDATE scripts SET name=?, vendor_id=?, script_type=?, language=?, content=?, filename_pattern=?, commands=? WHERE id=?',
                   (data['name'], vendor_id, data.get('script_type', 'backup'), data['language'], data['content'], 
                    data.get('filename_pattern', '{ip}-{date}.cfg'), data.get('commands', ''), script_id))
        db.commit()
        return jsonify({'success': True})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)})

@app.route('/api/admin/scripts/toggle/<int:script_id>', methods=['POST'])
@admin_required
def api_toggle_script(script_id):
    try:
        db = get_db()
        script = db.execute('SELECT * FROM scripts WHERE id=?', (script_id,)).fetchone()
        new_state = 0 if script['enabled'] else 1
        db.execute('UPDATE scripts SET enabled=? WHERE id=?', (new_state, script_id))
        db.commit()
        return jsonify({'success': True})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)})

@app.route('/api/admin/scripts/delete/<int:script_id>', methods=['DELETE'])
@admin_required
def api_delete_script(script_id):
    try:
        db = get_db()
        db.execute('DELETE FROM scripts WHERE id=?', (script_id,))
        db.commit()
        return jsonify({'success': True})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)})

# TEST - REAL EXECUTION
@app.route('/admin/test')
@admin_required
def admin_test():
    db = get_db()
    scripts = db.execute('SELECT * FROM scripts WHERE enabled=1 ORDER BY name').fetchall()
    devices = db.execute('SELECT d.*, v.name as vendor_name FROM devices d JOIN vendors v ON d.vendor_id=v.id WHERE d.enabled=1 ORDER BY d.ip_address').fetchall()
    return render_template('admin_test.html', scripts=scripts, devices=devices)

@app.route('/api/admin/scripts/test', methods=['POST'])
@admin_required
def api_test_script():
    try:
        data = request.get_json()
        script_id = data.get('script_id')
        device_id = data.get('device_id')
        
        db = get_db()
        script = db.execute('SELECT * FROM scripts WHERE id=?', (script_id,)).fetchone()
        device = db.execute('SELECT d.*, v.name as vendor_name FROM devices d JOIN vendors v ON d.vendor_id=v.id WHERE d.id=?', (device_id,)).fetchone()
        
        if not script or not device:
            return jsonify({'success': False, 'output': 'Script or device not found'})
        
        # Create temp script file
        script_file = f"{SCRIPTS_DIR}/temp_script_{script_id}.py"
        with open(script_file, 'w') as f:
            f.write(script['content'])
        
        os.chmod(script_file, 0o755)
        
        # Execute REAL script
        output = f"[REAL EXECUTION] Testing '{script['name']}' on {device['ip_address']}...\n"
        output += f"Device: {device['hostname']} ({device['vendor_name']})\n"
        output += f"Method: {device['method']}\n\n"
        
        try:
            result = subprocess.run(
                ['python3', script_file, device['ip_address']],
                capture_output=True,
                text=True,
                timeout=60
            )
            
            output += "=== STDOUT ===\n"
            output += result.stdout
            
            if result.stderr:
                output += "\n=== STDERR ===\n"
                output += result.stderr
            
            output += f"\n=== EXIT CODE: {result.returncode} ===\n"
            
            # Clean up temp file
            os.remove(script_file)
            
            return jsonify({'success': True, 'output': output})
            
        except subprocess.TimeoutExpired:
            output += "\n[ERROR] Script execution timeout (60s)"
            os.remove(script_file)
            return jsonify({'success': False, 'output': output})
            
        except Exception as e:
            output += f"\n[ERROR] {str(e)}"
            if os.path.exists(script_file):
                os.remove(script_file)
            return jsonify({'success': False, 'output': output})
        
    except Exception as e:
        return jsonify({'success': False, 'output': f'Error: {str(e)}'})

# CRON
@app.route('/admin/cron')
@admin_required
def admin_cron():
    db = get_db()
    
    # Get jobs with details
    jobs = db.execute('''
        SELECT 
            s.*,
            sc.name as script_name,
            v.name as vendor_name,
            n.name as network_name,
            d.ip_address as device_ip,
            d.hostname as device_hostname,
            (SELECT COUNT(*) FROM devices WHERE 
                (s.vendor_id IS NULL OR vendor_id = s.vendor_id) AND
                (s.network_id IS NULL OR network_id = s.network_id) AND
                (s.device_id IS NULL OR id = s.device_id) AND
                enabled = 1
            ) as device_count
        FROM schedules s
        LEFT JOIN scripts sc ON s.script_id = sc.id
        LEFT JOIN vendors v ON s.vendor_id = v.id
        LEFT JOIN networks n ON s.network_id = n.id
        LEFT JOIN devices d ON s.device_id = d.id
        ORDER BY s.name
    ''').fetchall()
    
    # Get dropdowns data
    scripts = db.execute('SELECT * FROM scripts WHERE enabled=1 ORDER BY name').fetchall()
    networks = db.execute('SELECT * FROM networks WHERE enabled=1 ORDER BY name').fetchall()
    devices = db.execute('''
        SELECT d.*, v.name as vendor_name 
        FROM devices d 
        JOIN vendors v ON d.vendor_id=v.id 
        WHERE d.enabled=1 
        ORDER BY d.ip_address
    ''').fetchall()
    
    return render_template('admin_cron.html', 
                         jobs=jobs, 
                         scripts=scripts, 
                         vendors=vendors, 
                         networks=networks,
                         devices=devices)

@app.route('/api/admin/cron/add', methods=['POST'])
@admin_required
def api_add_cron():
    try:
        print("[API] ========== ADD CRON CALLED ==========")
        data = request.get_json()
        print(f"[API] Data received: {data}")
        print(f"[API] vendor_id: {data.get('vendor_id')} (type: {type(data.get('vendor_id'))})")
        print(f"[API] network_id: {data.get('network_id')} (type: {type(data.get('network_id'))})")
        print(f"[API] device_id: {data.get('device_id')} (type: {type(data.get('device_id'))})")
        
        db = get_db()
        db.execute('INSERT INTO schedules (name, cron_expression, script_id, vendor_id, network_id, device_id, enabled) VALUES (?, ?, ?, ?, ?, ?, ?)',
                   (data['name'], data['cron_expression'], data.get('script_id'), 
                    data.get('vendor_id'), data.get('network_id'), data.get('device_id'), 1))
        db.commit()
        print(f"[API] Job '{data['name']}' inserted into database")
        
        print("[API] Calling load_cron_jobs()...")
        try:
            load_cron_jobs()  # Reload cron jobs
            print("[API] load_cron_jobs() completed successfully")
        except Exception as load_error:
            print(f"[API] ❌ ERROR in load_cron_jobs(): {load_error}")
            import traceback
            traceback.print_exc()
        
        print("[API] ========== ADD CRON COMPLETED ==========")
        return jsonify({'success': True})
    except Exception as e:
        print(f"[API] ❌ ERROR in api_add_cron: {e}")
        import traceback
        traceback.print_exc()
        return jsonify({'success': False, 'error': str(e)})

@app.route("/api/admin/cron/update/<int:job_id>", methods=["PUT"])
@admin_required
def api_update_cron(job_id):
    try:
        data = request.get_json()
        db = get_db()
        db.execute("""UPDATE schedules SET 
            name=?, cron_expression=?, script_id=?, vendor_id=?, network_id=?, device_id=? 
            WHERE id=?""",
            (data["name"], data["cron_expression"], data["script_id"],
             data.get("vendor_id") or None, data.get("network_id") or None,
             data.get("device_id") or None, job_id))
        db.commit()
        load_cron_jobs()
        return jsonify({"success": True})
    except Exception as e:
        return jsonify({"success": False, "error": str(e)})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)})

@app.route('/api/admin/cron/toggle/<int:job_id>', methods=['POST'])
@admin_required
def api_toggle_cron(job_id):
    try:
        db = get_db()
        job = db.execute('SELECT * FROM schedules WHERE id=?', (job_id,)).fetchone()
        new_state = 0 if job['enabled'] else 1
        db.execute('UPDATE schedules SET enabled=? WHERE id=?', (new_state, job_id))
        db.commit()
        load_cron_jobs()  # Reload cron jobs
        return jsonify({'success': True})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)})

@app.route('/api/admin/cron/run/<int:job_id>', methods=['POST'])
@admin_required
def api_run_cron(job_id):
    try:
        print(f"[API] Manual run requested for job {job_id}")
        db = get_db()
        
        if not job:
            print(f"[API] Job {job_id} not found")
            return jsonify({'success': False, 'error': 'Job not found'})
        
        print(f"[API] Executing job '{job['name']}' manually...")
        
        # Run SYNCHRONOUSLY for debugging (not background!)
        try:
            run_cron_job(job_id)
            print(f"[API] Manual execution of job {job_id} completed")
            return jsonify({'success': True, 'message': 'Job executed successfully'})
        except Exception as e:
            print(f"[API] ❌ ERROR running job {job_id}: {e}")
            import traceback
            traceback.print_exc()
            return jsonify({'success': False, 'error': str(e)})
    except Exception as e:
        print(f"[API] Error running job {job_id}: {e}")
        import traceback
        traceback.print_exc()
        return jsonify({'success': False, 'error': str(e)})

@app.route('/api/admin/cron/delete/<int:job_id>', methods=['DELETE'])
@admin_required
def api_delete_cron(job_id):
    try:
        db = get_db()
        
        # Remove from scheduler
        try:
            scheduler.remove_job(f"cron_{job_id}")
        except:
            pass
        
        # Delete from database
        db.execute('DELETE FROM schedules WHERE id=?', (job_id,))
        db.commit()
        
        return jsonify({'success': True})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500

# SSL
@app.route('/admin/ssl')
@admin_required
def admin_ssl():
    return render_template('admin_ssl.html')

@app.route('/api/admin/ssl/request', methods=['POST'])
@admin_required
def api_ssl_request():
    try:
        data = request.get_json()
        return jsonify({'success': True, 'message': 'SSL certificate request submitted'})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)})


@app.route('/api/admin/scheduler/test')
@admin_required
def test_scheduler():
    """Test if scheduler is working"""
    from datetime import datetime, timedelta
    
    # Add a test job that runs in 10 seconds
    def test_job():
        print("[SCHEDULER TEST] ✅ Scheduler is WORKING!")
        log_msg("[SCHEDULER TEST] Test job executed successfully!")
    
    run_time = datetime.now() + timedelta(seconds=10)
    scheduler.add_job(
        test_job,
        'date',
        run_date=run_time,
        id='test_scheduler'
    )
    
    return jsonify({
        'success': True,
        'message': f'Test job scheduled for {run_time}. Check logs in 10 seconds.',
        'scheduler_running': scheduler.running,
        'jobs_count': len(scheduler.get_jobs())
    })

@app.route('/api/admin/scheduler/status')
@admin_required
def scheduler_status():
    """Get scheduler status"""
    jobs = []
    for job in scheduler.get_jobs():
        jobs.append({
            'id': job.id,
            'next_run': str(job.next_run_time),
            'func': job.func.__name__
        })
    
    return jsonify({
        'running': scheduler.running,
        'jobs_count': len(jobs),
        'jobs': jobs
    })

# UPDATE ROUTES
@app.route('/api/admin/vendors/update/<int:vendor_id>', methods=['PUT'])
@admin_required
def api_update_vendor(vendor_id):
    try:
        data = request.get_json()
        db = get_db()
        db.execute('UPDATE vendors SET name=?, default_method=?, default_port=?, description=? WHERE id=?',
                   (data['name'], data['default_method'], data.get('default_port'), data.get('description'), vendor_id))
        db.commit()
        return jsonify({'success': True})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)})

@app.route('/api/admin/vendors/delete/<int:vendor_id>', methods=['DELETE'])
@admin_required
def api_delete_vendor(vendor_id):
    try:
        db = get_db()
        db.execute('DELETE FROM vendors WHERE id=?', (vendor_id,))
        db.commit()
        return jsonify({'success': True})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)})

@app.route('/api/admin/networks/update/<int:network_id>', methods=['PUT'])
@admin_required
def api_update_network(network_id):
    try:
        data = request.get_json()
        db = get_db()
        db.execute('UPDATE networks SET name=?, network_range=?, snmp_community=?, description=? WHERE id=?',
                   (data['name'], data['network_range'], data.get('snmp_community', 'public'), data.get('description', ''), network_id))
        db.commit()
        return jsonify({'success': True})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)})

@app.route('/api/admin/credentials/update/<int:cred_id>', methods=['PUT'])
@admin_required
def api_update_credential(cred_id):
    try:
        data = request.get_json()
        db = get_db()
        vendor_id = data.get('vendor_id') if data.get('vendor_id') != '' else None
        db.execute('UPDATE credentials SET vendor_id=?, username=?, password=?, priority=? WHERE id=?',
                   (vendor_id, data['username'], data['password'], data.get('priority', 0), cred_id))
        db.commit()
        return jsonify({'success': True})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)})

@app.route('/api/admin/users/update/<int:user_id>', methods=['PUT'])
@admin_required
def api_update_user(user_id):
    try:
        data = request.get_json()
        db = get_db()
        db.execute('UPDATE users SET username=?, role=?, email=? WHERE id=?',
                   (data['username'], data.get('role', 'user'), data.get('email', ''), user_id))
        if 'password' in data and data['password']:
            hashed = hashlib.sha256(data['password'].encode()).hexdigest()
            db.execute('UPDATE users SET password=? WHERE id=?', (hashed, user_id))
        db.commit()
        return jsonify({'success': True})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)})


@app.route('/api/admin/cron/data')
@admin_required
def api_cron_data():
    """Get dropdown data for cron form"""
    db = get_db()
    return jsonify({
        'scripts': [dict(s) for s in db.execute('SELECT id, name FROM scripts WHERE enabled=1 ORDER BY name').fetchall()],
        'vendors': [dict(v) for v in db.execute('SELECT id, name FROM vendors WHERE enabled=1 ORDER BY name').fetchall()],
        'networks': [dict(n) for n in db.execute('SELECT id, name FROM networks WHERE enabled=1 ORDER BY name').fetchall()],
        'devices': [dict(d) for d in db.execute('SELECT d.id, d.ip_address, d.hostname, v.name as vendor_name FROM devices d JOIN vendors v ON d.vendor_id=v.id WHERE d.enabled=1 ORDER BY d.ip_address').fetchall()]
    })


@app.route('/admin/backup/<int:backup_id>')
@login_required
def view_backup_alias(backup_id):
    """Alias for view_backup - accessible by all users"""
    return view_backup(backup_id)

@app.route('/admin/backup/<int:backup_id>/view')
@login_required
def view_backup(backup_id):
    """View backup file content"""
    db = get_db()
    backup = db.execute('SELECT * FROM backup_history WHERE id=?', (backup_id,)).fetchone()
    
    if not backup:
        return "Backup not found", 404
    
    if not backup['file_path'] or not os.path.exists(backup['file_path']):
        return "Backup file not found", 404
    
    try:
        with open(backup['file_path'], 'r', encoding='utf-8', errors='ignore') as f:
            content = f.read()
        return render_template('view_backup.html', backup=backup, content=content)
    except Exception as e:
        return f"Error reading backup: {str(e)}", 500

@app.route('/admin/backup/<int:backup_id>/download')
@login_required
def download_backup(backup_id):
    """Download backup file"""
    db = get_db()
    backup = db.execute('SELECT * FROM backup_history WHERE id=?', (backup_id,)).fetchone()
    
    if not backup:
        return "Backup not found", 404
    
    if not backup['file_path'] or not os.path.exists(backup['file_path']):
        return "Backup file not found", 404
    
    return send_file(backup['file_path'], as_attachment=True)

@app.route('/api/admin/backup/<int:backup_id>/delete', methods=['DELETE'])
@admin_required
def delete_backup(backup_id):
    """Delete backup file and history entry"""
    try:
        db = get_db()
        backup = db.execute('SELECT * FROM backup_history WHERE id=?', (backup_id,)).fetchone()
        
        if not backup:
            return jsonify({'success': False, 'error': 'Backup not found'}), 404
        
        # Delete physical file if exists
        if backup['file_path'] and os.path.exists(backup['file_path']):
            try:
                os.remove(backup['file_path'])
                print(f"[DELETE] Removed file: {backup['file_path']}")
            except Exception as e:
                print(f"[DELETE] Error removing file: {e}")
        
        # Delete database entry
        db.execute('DELETE FROM backup_history WHERE id=?', (backup_id,))
        db.commit()
        
        print(f"[DELETE] Deleted backup {backup_id} for {backup['ip_address']}")
        return jsonify({'success': True})
    except Exception as e:
        print(f"[DELETE] Error: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/api/admin/device/<int:device_id>/backups/delete-failed', methods=['DELETE'])
@admin_required
def delete_failed_backups(device_id):
    """Delete all failed backup entries for a device"""
    try:
        db = get_db()
        
        # Get device info
        device = db.execute('SELECT ip_address FROM devices WHERE id=?', (device_id,)).fetchone()
        if not device:
            return jsonify({'success': False, 'error': 'Device not found'}), 404
        
        # Get all failed backups for this device
        failed_backups = db.execute('''
            SELECT id, file_path FROM backup_history 
            WHERE device_id=? AND status='failed'
        ''', (device_id,)).fetchall()
        
        deleted_count = 0
        for backup in failed_backups:
            # Delete physical file if exists
            if backup['file_path'] and os.path.exists(backup['file_path']):
                try:
                    os.remove(backup['file_path'])
                except:
                    pass
            deleted_count += 1
        
        # Delete all failed entries from database
        db.execute('DELETE FROM backup_history WHERE device_id=? AND status=?', (device_id, 'failed'))
        db.commit()
        
        print(f"[DELETE] Deleted {deleted_count} failed backups for device {device_id}")
        return jsonify({'success': True, 'deleted': deleted_count})
    except Exception as e:
        print(f"[DELETE] Error: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500

def initialize():
    print("[STARTUP] Vasil Dobchev - supportpc.org Backup Manager starting...")
    os.makedirs(BACKUP_DIR, exist_ok=True)
    os.makedirs(SCRIPTS_DIR, exist_ok=True)
    os.makedirs(os.path.dirname(DB_FILE), exist_ok=True)
    os.makedirs('/data/logs', exist_ok=True)
    init_db()
    
    # Load scheduled jobs from database
    print("[STARTUP] Loading scheduled jobs...")
    load_cron_jobs()
    print("[STARTUP] Startup complete!")

if __name__ == '__main__':
    initialize()
    app.run(host='0.0.0.0', port=8086, debug=False, threaded=True)
